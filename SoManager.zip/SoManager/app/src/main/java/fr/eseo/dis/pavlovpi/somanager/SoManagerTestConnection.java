package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SoManagerTestConnection extends AppCompatActivity {

    Button btnGetRequest, btnPostRequest;

    EditText textUserName;
    EditText textPassword;

    private String userName;
    private String password;

    private String pageType = "LOGON";
    private String baseUrl = "https://192.168.4.248/pfe/webservice.php?q=" + pageType +"&user=";
    private String url;

    private String result;
    private String api;
    private String token;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_connection);

        nukeSSLcerts.nuke();

        mRequestQueue = Volley.newRequestQueue(this);

        init();
    }

    private void init() {
        getViews();
        setListeners();
        //restClient = HTTPSRestClient.getInstance();
    }

    private void getViews() {
        /**
         btnGetRequest = (Button) findViewById(R.id.btnGetRequest);
         btnPostRequest = (Button) findViewById(R.id.btnPostRequest);
         textResponse = (TextView) findViewById(R.id.textResponse);
         **/
        btnGetRequest = (Button) findViewById(R.id.connexion_button);
        btnPostRequest = (Button) findViewById(R.id.connexion_button);
        //textResponse = (TextView) findViewById(R.id.textResponse);

        textUserName = (EditText) findViewById(R.id.user_name); //voir pour en faire une méthode après
        textPassword = findViewById(R.id.password);
    }

    private void setListeners() {
        btnGetRequest.setOnClickListener(new View.OnClickListener() {
            //EditText textTest = findViewById(R.id.user_name);
            @Override
            public void onClick(View v) {

                userName = "chavijer"; //textUserName.getText().toString();
                url = baseUrl + userName;

                url = url + "&pass=";
                password = "78MYzDuUcGYh"; //textPassword.getText().toString();
                url = url + password;

                Log.d("TextConnectionURL = ", url);

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                Log.d("TestConnectionDelta", "connexion Volley OK");

                                try {

                                    result = response.getString("result");
                                    api = response.getString("api");
                                    token = response.getString("token");

                                    if(result.equals("OK")){
                                        Log.d("TestConnectionDelta","checkResult est true");
                                        Intent myIntent = new Intent(SoManagerTestConnection.this, SoManagerActivity.class);
                                        myIntent.putExtra("user_name",userName);
                                        myIntent.putExtra("token",token);
                                        startActivity(myIntent);
                                    } else {
                                        Log.e("TestConnectionDelta","checkResult est FALSE");
                                    }

                                    Log.d("TestConnectionDelta", "Le token = " + token);

                                } catch (JSONException e) {
                                    Log.e("TestConnectionDelta","JSON a pas marché");
                                    e.printStackTrace();
                                }


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("TestConnectionDelta", "connexion VolleyError");
                        error.printStackTrace();
                    }
                });

                mRequestQueue.add(request);

            }
        });

    }
}
