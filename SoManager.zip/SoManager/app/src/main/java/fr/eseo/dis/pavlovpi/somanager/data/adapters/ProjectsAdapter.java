package fr.eseo.dis.pavlovpi.somanager.data.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

import fr.eseo.dis.pavlovpi.somanager.R;
import fr.eseo.dis.pavlovpi.somanager.data.ProjectItem;

public class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ProjectsViewHolder> {
    private Context mContext;
    private ArrayList<ProjectItem> mProjectList;

    public ProjectsAdapter(Context context, ArrayList<ProjectItem> projectList){
        this.mContext = context;
        this.mProjectList = projectList;
    }

    @NonNull
    @Override
    public ProjectsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.projects_card_view, parent, false);
        return new ProjectsViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectsViewHolder holder, int position) {
        ProjectItem currentItem = mProjectList.get(position);

        String idProject = currentItem.getIdProject();
        String titleProject = currentItem.getTitleProject();
        String descriptionProject = currentItem.getDescriptionProject();

        holder.mTextViewIdProject.setText("Id_Project = " + idProject);
        holder.mTextViewTitleProject.setText("Titre_Projet :" + titleProject);
        holder.mTextViewDescriptionProject.setText("Description : " + descriptionProject);
    }

    @Override
    public int getItemCount() {
        return this.mProjectList.size();
    }

    public class ProjectsViewHolder extends RecyclerView.ViewHolder{

        public TextView mTextViewIdProject;
        public TextView mTextViewTitleProject;
        public TextView mTextViewDescriptionProject;

        public ProjectsViewHolder(View itemView) {
            super(itemView);
            mTextViewIdProject = itemView.findViewById(R.id.project_id_view);
            mTextViewTitleProject = itemView.findViewById(R.id.project_title_view);
            mTextViewDescriptionProject = itemView.findViewById(R.id.project_description_view);
        }

    }

}
