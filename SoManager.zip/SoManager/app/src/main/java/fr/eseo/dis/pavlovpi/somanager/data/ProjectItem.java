package fr.eseo.dis.pavlovpi.somanager.data;

public class ProjectItem {

    private String idProject;
    private String titleProject;
    private String descriptionProject;

    public ProjectItem(String idProject, String titleProject, String descriptionProject){
        this.idProject = idProject;
        this.titleProject = titleProject;
        this.descriptionProject = descriptionProject;
    }

    public String getIdProject() {
        return this.idProject;
    }

    public String getTitleProject() {
        return this.titleProject;
    }

    public String getDescriptionProject() {
        return this.descriptionProject;
    }
}
